
  # Login page (Community)

  This is a code bundle for Login page (Community). The original project is available at https://www.figma.com/design/abLkPjNPwmDW25FbZZZGtR/Login-page--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  